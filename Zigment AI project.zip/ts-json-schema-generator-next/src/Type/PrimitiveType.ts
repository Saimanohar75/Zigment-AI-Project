import { BaseType } from "./BaseType.js";

export abstract class PrimitiveType extends BaseType {}
