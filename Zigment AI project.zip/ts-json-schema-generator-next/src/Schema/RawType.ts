import { JSONSchema7Type, JSONSchema7TypeName } from "json-schema";

export type RawType = JSONSchema7Type;
export type RawTypeName = JSONSchema7TypeName;
