import { JSONSchema7 } from "json-schema";

export type Schema = JSONSchema7;
