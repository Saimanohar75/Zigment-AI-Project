import { JSONSchema7 } from "json-schema";

export type Definition = JSONSchema7;
