export interface StringMap<T> {
    [key: string]: T;
}
