export interface MyType {
    numberArray: number[];
    stringArray: readonly string[];
}
