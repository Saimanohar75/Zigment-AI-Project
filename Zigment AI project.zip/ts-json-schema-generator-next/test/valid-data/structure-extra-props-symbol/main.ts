export interface MyObject {
    structure: {
        [name: string]: symbol;
    };
}
