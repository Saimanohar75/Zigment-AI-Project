export class MyObject {
    public required: string;
    public optional?: number;
    [name: string]: string | number;
}
