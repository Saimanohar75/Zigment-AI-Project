export interface MyObject {
    value1: any;
    value2: unknown;
}
