export enum A {
    B,
    C,
    D,
}

export interface MyObject {
    code: A.B;
}
