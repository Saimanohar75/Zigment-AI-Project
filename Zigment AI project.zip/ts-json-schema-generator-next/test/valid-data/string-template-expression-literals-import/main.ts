import { MyType } from "./types";

export interface MyObject {
    value: `_${MyType}`;
}
