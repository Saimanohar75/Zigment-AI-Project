export type MyType = "one" | "two" | "three";
