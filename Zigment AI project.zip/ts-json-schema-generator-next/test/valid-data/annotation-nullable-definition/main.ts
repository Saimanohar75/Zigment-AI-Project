export class Definition {
    name: string;
}

export class MyObject {
    /**
     * @nullable
     */
    optional?: Definition[];
}
