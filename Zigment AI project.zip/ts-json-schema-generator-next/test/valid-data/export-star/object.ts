export interface D {
    a: 1;
}

export class E {
    b: 2;
}

interface F {
    internal: true;
}
