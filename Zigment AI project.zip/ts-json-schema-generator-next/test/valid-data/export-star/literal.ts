export type A = 1;

export type B = "string";

type C = "internal";
