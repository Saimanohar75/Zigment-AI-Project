export * from "./literal";
export * from "./object";

export type External = 1;

type Internal = 2;
