export interface MyObject {
    foo: symbol;
}
