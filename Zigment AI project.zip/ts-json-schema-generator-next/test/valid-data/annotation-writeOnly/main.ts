export interface MyObject {
    one?: string;
    /** @writeOnly */
    two?: number;
}
