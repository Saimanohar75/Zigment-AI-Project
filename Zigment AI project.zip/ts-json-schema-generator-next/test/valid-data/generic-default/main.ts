export type MyObject = Generic;

export interface Generic<N = number> {
    foo: N;
}
