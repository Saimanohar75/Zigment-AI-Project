export type BasicNever = never;
