export type MyType = [string?, string?];
