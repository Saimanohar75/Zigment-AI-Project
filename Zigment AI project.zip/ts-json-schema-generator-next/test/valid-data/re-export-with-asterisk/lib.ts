export enum MyEnum {
    Foo = "foo",
    Bar = "bar",
}

export interface MyObject {
    id: string;
}
