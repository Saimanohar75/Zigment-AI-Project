export { MyObject } from "./lib";
import { MyEnum } from "./lib";
export { MyEnum };
