export interface ExposedSubType {
    subvalue: number;
}

export interface MySubObject {
    value: ExposedSubType;
}
