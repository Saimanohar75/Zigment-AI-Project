const arr = ["abc", "def"] as const;
export type MyType = typeof arr;
