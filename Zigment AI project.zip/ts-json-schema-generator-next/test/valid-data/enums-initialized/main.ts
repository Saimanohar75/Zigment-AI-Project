export enum Enum {
    X = 10,
    Y,
    Z,
    A = 1,
}
