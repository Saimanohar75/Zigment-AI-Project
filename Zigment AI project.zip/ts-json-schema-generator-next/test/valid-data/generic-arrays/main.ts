export interface MyObject {
    numberArray: Array<number>;
    stringArray: ReadonlyArray<string>;
}
