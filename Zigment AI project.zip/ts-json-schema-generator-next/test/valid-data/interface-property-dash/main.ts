export interface MyObject {
    "with-dash": string;
    without: string;
    nodash: string;
}
