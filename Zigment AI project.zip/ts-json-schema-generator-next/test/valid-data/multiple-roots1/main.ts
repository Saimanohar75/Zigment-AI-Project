export interface MyObject1 {
    propA: MyObject2;
}

export interface MyObject2 {
    propB: string;
}

export interface MyObject3 {
    propC: boolean;
}
