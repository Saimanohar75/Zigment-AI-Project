export const Foo = {
    x: 1,
    y: 1,
};

export type MyType = keyof typeof Foo;
