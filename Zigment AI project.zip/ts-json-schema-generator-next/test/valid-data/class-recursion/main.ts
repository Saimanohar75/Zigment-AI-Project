export class MyObject {
    public propA: number;
    public propB: MyObject;
}
