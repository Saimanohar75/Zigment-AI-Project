/**
 * @deprecated
 * @deprecationMessage Use `NewMyObject` instead.
 */
export interface MyObject {
    one?: string;
    /** @deprecated */
    two?: number;
}
