export const myFunction = (
    /**
     * @description Inline parameter description
     */
    requiredString: string,
) => {
    return "whatever";
};
