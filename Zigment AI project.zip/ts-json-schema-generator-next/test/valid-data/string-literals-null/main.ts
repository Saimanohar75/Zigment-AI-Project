export interface MyObject {
    enum1: "a" | "b" | null;
    enum2: "a" | "b";
}
