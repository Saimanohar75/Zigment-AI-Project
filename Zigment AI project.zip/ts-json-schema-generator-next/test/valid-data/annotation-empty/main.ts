/**
 * @customEmptyAnnotation
 */
export interface MyObject {}
