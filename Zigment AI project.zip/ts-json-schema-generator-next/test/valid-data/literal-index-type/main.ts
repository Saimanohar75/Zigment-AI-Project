const arr = ["abc", "def"];
export type MyType = (typeof arr)[number];
