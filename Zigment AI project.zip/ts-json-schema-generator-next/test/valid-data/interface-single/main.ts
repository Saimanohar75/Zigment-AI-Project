export interface MyObject {
    propA: number;
    propB: number;
    readonly propC: string;
}
