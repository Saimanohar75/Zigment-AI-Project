export interface Asset {
    readonly type: "One" | "Two";
}
