import { Asset } from "../Asset";

export type MyAsset = Asset;
