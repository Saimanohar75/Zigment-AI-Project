export interface SimpleObject {
    required: string;
    optional?: number;
}
