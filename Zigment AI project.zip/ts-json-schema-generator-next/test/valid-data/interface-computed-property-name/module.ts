export const key = "exportedKey";

export enum Keys {
    Key = "exportedEnumKey",
}
