export function arrayGenerics<T>(a: T[], b: T[]): T[] {
    console.log(a, b);
    return b;
}
