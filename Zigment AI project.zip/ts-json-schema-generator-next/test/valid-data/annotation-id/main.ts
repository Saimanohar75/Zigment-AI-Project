/**
 * @id #MyObject
 */
export interface MyObject {
    nested: MyNestedObject;
}

/**
 * @id #MyNestedObject
 */
export interface MyNestedObject {}
