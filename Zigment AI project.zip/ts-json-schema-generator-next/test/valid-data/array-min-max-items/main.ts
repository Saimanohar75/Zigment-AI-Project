export type MyType = [string, string, string];
