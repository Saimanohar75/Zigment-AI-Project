export const myFunction = (optionalString?: string) => {
    return "whatever";
};
