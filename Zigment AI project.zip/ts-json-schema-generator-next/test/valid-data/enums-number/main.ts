export enum Enum {
    X = 1,
    Y = 2,
}
