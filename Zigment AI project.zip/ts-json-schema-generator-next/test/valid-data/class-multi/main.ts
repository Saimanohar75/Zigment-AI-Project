export class MyObject {
    public subA: MySubObject;
    public subB: MySubObject;
}
export class MySubObject {
    public propA: number;
    public propB: number;
}
