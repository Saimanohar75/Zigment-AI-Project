export interface MyObject {
    one?: string;
    /** @readOnly */
    two?: number;
}
