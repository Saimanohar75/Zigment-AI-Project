/** The built-in color schemes, cased. */
type Foo = "Accent";

export type MyType = Lowercase<Foo>;
