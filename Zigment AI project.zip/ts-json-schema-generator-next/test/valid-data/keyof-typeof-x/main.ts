const myprop = 0;
export const mymap = { myprop };
export type MyType = keyof typeof mymap;
