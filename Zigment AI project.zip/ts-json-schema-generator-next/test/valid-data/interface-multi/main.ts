export interface MyObject {
    subA: MySubObject;
    subB: MySubObject;
}
export interface MySubObject {
    propA: number;
    propB: number;
}
