export const myFunction = (requiredString: string) => {
    return "whatever";
};
