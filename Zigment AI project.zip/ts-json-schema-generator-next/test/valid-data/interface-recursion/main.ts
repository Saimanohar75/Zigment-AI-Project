export interface MyObject {
    propA: number;
    propB: MyObject;
}
