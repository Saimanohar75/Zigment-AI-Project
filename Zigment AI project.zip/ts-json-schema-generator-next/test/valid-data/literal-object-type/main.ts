const obj = { abc: "def" };

export type MyType = typeof obj;
