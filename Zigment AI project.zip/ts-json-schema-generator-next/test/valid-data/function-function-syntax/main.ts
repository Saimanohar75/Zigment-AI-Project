export const myFunction = function () {};
