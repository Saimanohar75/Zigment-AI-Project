interface AnonymousSubType {
    subvalue: number;
}

export interface MySubObject {
    value: AnonymousSubType;
}
