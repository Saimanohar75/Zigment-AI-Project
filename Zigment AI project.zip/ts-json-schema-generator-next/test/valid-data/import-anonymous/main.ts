import { MySubObject } from "./module";

export interface MyObject {
    field: MySubObject;
}
