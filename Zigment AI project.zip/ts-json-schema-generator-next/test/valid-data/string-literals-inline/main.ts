export interface MyObject {
    foo: "ok" | "fail" | "abort";
    bar: "ok" | "fail" | "abort" | string;
}
