// This form is recommended by the typescript-eslint rule "ban-types" to mean
// "an object with no properties"
export type Mapped = Record<string, never>;
