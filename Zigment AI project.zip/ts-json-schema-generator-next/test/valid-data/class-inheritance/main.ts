export class Base {
    public a: number;
    public b: string | string;
}

export class MyObject extends Base {
    public c: boolean;
    public b: string;
}
