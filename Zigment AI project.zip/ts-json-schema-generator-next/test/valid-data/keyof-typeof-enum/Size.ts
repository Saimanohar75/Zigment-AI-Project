export enum Size {
    Small,
    Medium,
    Large,
}
