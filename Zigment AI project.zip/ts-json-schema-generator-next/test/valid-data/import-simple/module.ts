export interface MySubObject {
    value: number;
}
