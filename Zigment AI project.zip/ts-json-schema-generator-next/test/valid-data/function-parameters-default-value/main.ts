export const myFunction = (paramWithDefault: string = "something") => {
    return "whatever";
};
