export interface MyObject {
    /**
     * @nullable
     */
    optional?: MyObject | null;
}
