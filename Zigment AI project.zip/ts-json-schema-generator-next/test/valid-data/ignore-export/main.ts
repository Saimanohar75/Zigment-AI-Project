// This constant should be ignored
const foo = [].map(() => {});

export class A {
    a: string;
}

export class B {
    b: string;
}
