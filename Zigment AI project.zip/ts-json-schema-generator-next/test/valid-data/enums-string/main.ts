export enum Enum {
    X = "x",
    Y = "y",
}
