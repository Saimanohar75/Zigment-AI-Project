/**
 * @discriminator name
 */
export interface MyType {
    name: string;
}
