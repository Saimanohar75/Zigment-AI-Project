export type A = number;
