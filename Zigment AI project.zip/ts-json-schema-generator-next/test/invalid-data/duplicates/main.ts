import { A as A1 } from "./import1";
import { A as A2 } from "./import2";

export type MyType = A1 | A2;
