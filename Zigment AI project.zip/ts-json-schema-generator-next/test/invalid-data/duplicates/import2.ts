export type A = string;
