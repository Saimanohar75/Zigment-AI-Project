export type A = 1;
export type B = 2;
export type C = 3;
