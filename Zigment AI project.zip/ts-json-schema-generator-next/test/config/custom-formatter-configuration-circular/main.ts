export interface InnerInterface {
    exportValue: string;
}

export interface MyObject {
    inner: InnerInterface;
}
