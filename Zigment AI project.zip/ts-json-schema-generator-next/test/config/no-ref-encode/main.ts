export type MyType<T> = T;

export type MyObject = MyType<number>;
