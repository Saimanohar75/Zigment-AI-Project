/**
 * Some description here
 */
export interface MyObject {}
