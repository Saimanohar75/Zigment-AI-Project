export type String = string;

export const myFunction = (
    /**
     * @description Inline parameter description
     */
    requiredString: String,
) => {
    return "whatever";
};
