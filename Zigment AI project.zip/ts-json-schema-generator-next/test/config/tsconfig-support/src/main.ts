import { MySubObject } from "@src/import1";

export interface MyObject {
    subObject: MySubObject;
}
