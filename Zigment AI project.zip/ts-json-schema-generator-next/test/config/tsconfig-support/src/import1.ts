export interface MySubObject {
    subValue: string;
}
