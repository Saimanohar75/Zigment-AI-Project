export type Schema = {
    a?: number;
};
